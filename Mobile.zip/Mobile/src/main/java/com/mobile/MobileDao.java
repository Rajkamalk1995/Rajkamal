package com.mobile;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MobileDao {
@Autowired
MobileRepository mr;
	public String setObj(Mobile m) {
	mr.save(m);
		return "saved";
	}
	public String setAllObj(List<Mobile> m) {
		mr.saveAll(m);
		return "perfect" ;
	}
	public List<Mobile> getAllObj() {
		
		return mr.findAll();
	}
	public Mobile getById(int id) {
		
		return mr.findById(id).get();
	}
	public String delById(int id) {
		mr.deleteById(id);
		return "deleted";
	}
	public List<Mobile> getByRam(int a) {
		List<Mobile>x=mr.findAll();
		List<Mobile>z=x.stream().filter(y->y.getRam()==a).collect(Collectors.toList());
		return z;
	}

}
