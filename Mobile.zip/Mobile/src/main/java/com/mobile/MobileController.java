package com.mobile;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MobileController {
	@Autowired
	MobileService ms;
	@PostMapping(value="/setObj")
	public String setObj(@RequestBody Mobile m) {
		return ms.setObj(m);
	}
	@PostMapping(value="/setAllObj")
	public String setAllObj(@RequestBody List<Mobile>m) {
		return ms.setAllObj(m);
	}
	@GetMapping(value="/getAllObj")
	public List<Mobile> getAllObj() {
		return ms.getAllObj();
	}
	@GetMapping(value="/getById/{id}")
	public Mobile getById(@PathVariable int id) {
		return ms.getById(id);
	}
	@DeleteMapping(value="/delById/{id}")
	public String delById(@PathVariable int id) {
		return ms.delById(id);
		
	}
	@GetMapping(value="/getByRam/{a}")
	public List<Mobile> getByRam(@PathVariable int a) {
		return ms.getByRam(a);
	}

}
