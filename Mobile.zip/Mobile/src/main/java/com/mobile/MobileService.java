package com.mobile;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

@Service
public class MobileService {
@Autowired
MobileDao md;
	public String setObj(Mobile m) {
		
		return md.setObj(m); 
	}
	
	public String setAllObj(List<Mobile> m) {
		
		return md.setAllObj(m);
	}

	public List<Mobile> getAllObj() {
		
		return md.getAllObj();
	}

	public Mobile getById(int id) {
		
		return md.getById(id);
	}

	public String delById(int id) {
		
		return md.delById(id);
	}

	public List<Mobile> getByRam(int a) {
		
		return md.getByRam(a);
	}

}
